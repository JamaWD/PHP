<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->


<?php

 $name = $_POST["name"];
 $principal = $_POST["principal"];
 $interest = $_POST["interest"];
 $years = $_POST["years"];
 $postalcode = $_POST["postalcode"];
 $phonenumber = $_POST["phonenumber"];
 $email = $_POST["email"];
 $preferredContact = $_POST["preferredContact"];
 $contactTimes = $_POST["contactTimes"];

 
$nameErr = $principalErr = $interestErr = $yearsErr = $postalcodeErr = $phonenumberErr = $emailErr = $preferredContactErr =
$contactTimesErr = "";




if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
 
if (empty($_POST["name"])) 
 {
    $nameErr = "<p>*Name is required*</p>";
 }
  

  
  
if (!is_numeric($_POST['principal'])  || $principal < 0 )
 {
     $principalErr = "<p>*Principal amount must be numeric*</p>";
 }
 
 
 if (!is_numeric($_POST['interest']) || $interest < 0)
 {
     $interestErr = "<p>*Interest rate must be non-negative*</p>";
 }
 
 
 if (!preg_match("/^[A-Z]\d[A-Z]\ ?\ \d[A-Z]\d$/", $postalcode))
 {
      $postalcodeErr = "<p>*Incorrect postal code*</p>";
 }
 

 if (!preg_match("/^[2-9]\d\d-[2-9]\d\d\-\d{4}$/", $phonenumber))
 {
     $phonenumberErr = "<p>*Incorrect phone number*</p>";
 }
 
 if (!preg_match("/^[A-Za-z\d.]+\@[A-Za-z\d]+\.[A-Za-z.]{2,4}$/" , $email))
 {
     $emailErr = "<p>*Invalid email*</p>";
 }

 
 if ($preferredContact === "Phone" && !isset($contactTimes)) 
 {
     $contactTimesErr = "<p>*When preferred contact is phone, you must select a contact time*</p>";
 }

 
 
 
  
      



 
 
 
 
 }
            
 



?>











<html>
    <head>
        <link rel="stylesheet" type="text/css" href="style.css">  
        <title>Lab3</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
    </head>
    <body>
        <h1 align="center">Deposit Calculator</h1>
        
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
            
         <table>
             
          <tr>
	       <td>Principal Amount:</td><td><input type = "text" placeholder="Principal Amount" name = "principal" value="<?= isset($_POST['principal']) ? $_POST['principal'] : ''; ?>"  /> <?php echo $principalErr;?></td>
          </tr>
          
           <tr>
	       <td>Interest Rate(%):</td><td><input type = "text" placeholder="Interest Rate" name = "interest" value="<?= isset($_POST['interest']) ? $_POST['interest'] : ''; ?>" />  <?php echo $interestErr;?></td>
          </tr>
          
          <TR>
    <TD> Years to Deposit: 
        <div class="selectWrapper">
    <select class ="select" name="years">        
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>   
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
    </select>
         </div>
        
          <tr>
	       <td>Name:</td><td><input type = "text" placeholder="Name" name = "name" value="<?= isset($_POST['name']) ? $_POST['name'] : ''; ?>" /><?php echo $nameErr;?> </td>
               
               
          
          </tr>
          
           <tr>
	       <td>Postal Code:</td><td><input type = "text" placeholder="Postal Code" name = "postalcode" value="<?= isset($_POST['postalcode']) ? $_POST['postalcode'] : ''; ?>" /> <?php echo $postalcodeErr;?></td>
          </tr>
          
           <tr>
	       <td>Phone Number:</td><td><input type = "text" placeholder="nnn-nnn-nnnn" name = "phonenumber" value="<?= isset($_POST['phonenumber']) ? $_POST['phonenumber'] : ''; ?>" /> <?php echo $phonenumberErr;?></td>
          </tr>
          
           <tr>
	       <td>Email Address:</td><td><input type = "text" placeholder="test123@hotmail.com" name = "email" value="<?= isset($_POST['email']) ? $_POST['email'] : ''; ?>" /> <?php echo $emailErr;?></td>
          </tr>
         
    
    </TD>   
</TR>
 
         </table>
            
      <h4>Preferred Contact Method:</h4>
       <input id="preferredContactPhone" name="preferredContact" type="radio" value="Phone"> Phone
       <input id="preferredContactEmail" name="preferredContact" type="radio" value="Email"> Email
       
      <h4>If phone is selected, when can we contact you? (check all applicable)</h4>
      
		<input type="checkbox" name="contactTimes[]" value="morning"/>Morning
			</tr>
			<tr>
		<input type="checkbox" name="contactTimes[]" value="afternoon"/>Afternoon
			</tr>
			<tr>
		<input type="checkbox" name="contactTimes[]" value="evening"/>Evening
                <?php echo $contactTimesErr;?>
      
				
     
      <input type = "submit" value = "Submit" style="position: absolute; top: 515px; left: 650px;" name="btnSubmit"/>
      <input type="reset" value="Clear" style="position: absolute; top: 515px; left: 750px;">
      
      
      
      
      
      <?php
      if (!$nameErr && !$principalErr && !$interestErr && !$yearsErr && !$postalcodeErr
          && !$phonenumberErr && !$emailErr && !$preferredContactErr && !$contactTimesErr && isset($_POST["btnSubmit"]))
          
      {
          showTable();
      }
     
      
      ?>
    

      
      
      
      
      
      <?php
      
      
      
      function showTable()
     {
          $name = $_POST["name"];
          $principal = $_POST["principal"];
          $interest = $_POST["interest"];
          $years = $_POST["years"];
          $postalcode = $_POST["postalcode"];
          $phonenumber = $_POST["phonenumber"];
          $email = $_POST["email"];
          $preferredContact = $_POST["preferredContact"];
          $contactTimes = $_POST["contactTimes"];
         
         echo "<h1>Thank you {$_POST['name']}, for using our deposit Calculator!</h1>";
         
         
         
         
         if(strcasecmp($preferredContact, "Phone") == 0) {
        	echo "Our customer service department will call you tomorrow $contactTimes at $phonenumber";
        }       
        else {
        	echo "Our customer service department will email you tomorrow at " . $email;
        }
         
         
         echo "<br>The following is the result of the calculation";
          echo "<table border='1'>
          <tr>
          <th>Year</th>
          <th>Principal at Year Start</th>
          <th>Interest for the Year</th>
          </tr>";
          
          $principleAtYearStart = $principal;
          for ($i = 1; $i<= $years; $i++)
          {
              
              $interestAmount =($principleAtYearStart * $interest) / 100.0;
              
              echo "<tr>";
              echo "<td>";
              echo $i;
              echo "</td>";              
              echo "<td>";
              echo printf("%.2f", $principleAtYearStart);
              echo "</td>"; 
              echo "<td>";
              echo printf("%.2f", $interestAmount);
              echo "</td>";  
              echo "</tr>";
         
              $principleAtYearStart += $interestAmount;
              
              
          }
          
          
          
          echo "</table>";
      }
         
         
         
     
     
      
      ?>
           
   
      
      
      
      
      
      
      
      
      
      
      
      
  <footer>
    <p class="copyright">© Ibrahim Jama Calculator</p>
</footer>
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
 



 </body>
    
    
    
    
</html>

