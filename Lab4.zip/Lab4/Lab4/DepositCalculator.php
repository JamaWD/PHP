<?php
session_start();
if(!isset($_SESSION['agree']))
{
      header("Location:Disclaimer.php");
}

if (!isset($_SESSION['name']) || !isset($_SESSION['postalcode']) || !isset($_SESSION['phonenumber'])
|| !isset($_SESSION['email']) || !isset($_SESSION['preferredContact']) || !isset($_SESSION['contactTimes'])) 
    
{ 
    header("Location:CustomerInfo.php");
    
}

 $principal = $_POST["principal"];
 $interest = $_POST["interest"];

 
 $principalErr = $interestErr = "";


if ($_SERVER["REQUEST_METHOD"] == "POST")
    
{
    
  if (!is_numeric($_POST['principal'])  || $principal < 0 )
 {
     $principalErr = "<p><font color=red>*Principal amount must be numeric*</font></p>";
 }
 
 
 if (!is_numeric($_POST['interest']) || $interest < 0)
 {
     $interestErr = "<p><font color=red>*Interest rate must be non-negative*</font></p>";
 }
 
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
      
     if (isset($_POST['clear']))
     {
         $principalErr = "";
         $interestErr = "";
     }
 }
 

        
}


?>


<html>
    <head>


        <meta charset="UTF-8">
        <title>Lab4</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>                        
                        </button>
                        <a class="navbar-brand" href="#">Algonquin College</a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="Index.php">Home</a></li>
                            <li><a href="Disclaimer.php">Terms and Conditions</a></li>
                            <li><a href="CustomerInfo.php">Customer Information</a></li>
                            <li><a href="DepositCalculator.php">Calculator</a></li>
                            <li><a href="Complete.php">Complete</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <h3 align="center">Enter principal amount, interest rate and select number of years to deposit</h3>

            <table align="center">

                <tr>
                    <br><td>Principal Amount:</td><td><input type = "text" placeholder="Principal" name = "principal"/> <?php echo $principalErr;?>
                </tr>
               

                <tr>
                    
                    <td>Interest Rate:</td><td><input type = "text" placeholder="Interest" name = "interest"/> <?php echo $interestErr;?>
                </tr>

                <tr>
                    <TD> Years to Deposit: 
                        <div class="selectWrapper">
                            <select class ="select" name="years">        
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                                <option value="13">13</option>
                                <option value="14">14</option>
                                <option value="15">15</option>
                                <option value="16">16</option>
                                <option value="17">17</option>   
                                <option value="18">18</option>
                                <option value="19">19</option>
                                <option value="20">20</option>
                            </select>
                        </div>

                </tr>

            </table



            <div>
                <input type = "submit" value = "Submit" style="position: absolute; top: 515px; left: 650px;" name="btnSubmit">
                <input type="submit" value="Clear" style="position: absolute; top: 515px; left: 750px;" name="clear">
                
            </div>
            
            
             <?php
      if (!$nameErr && !$principalErr && !$interestErr && !$yearsErr && !$postalcodeErr
          && !$phonenumberErr && !$emailErr && !$preferredContactErr && !$contactTimesErr && isset($_POST["btnSubmit"]))
          
      {
          showTable();
      }
     
      
      ?>
    

      
      
      
      
      
      <?php
      
      
      
      function showTable()
     {
       
          $principal = $_POST["principal"];
          $interest = $_POST["interest"];
          $years = $_POST["years"];
         
         
         echo "<br>The following is the result of the calculation";
          echo "<table border='1'>
          <tr>
          <th>Year</th>
          <th>Principal at Year Start</th>
          <th>Interest for the Year</th>
          </tr>";
          
          $principleAtYearStart = $principal;
          for ($i = 1; $i<= $years; $i++)
          {
              
              $interestAmount =($principleAtYearStart * $interest) / 100.0;
              
              echo "<tr>";
              echo "<td>";
              echo $i;
              echo "</td>";              
              echo "<td>";
              echo printf("%.2f", $principleAtYearStart);
              echo "</td>"; 
              echo "<td>";
              echo printf("%.2f", $interestAmount);
              echo "</td>";  
              echo "</tr>";
         
              $principleAtYearStart += $interestAmount;
              
              
          }
          
          
          
          echo "</table>";
      }
         
         
         
     
     
      
      ?>
           
   



            <footer style="position: absolute; bottom: 0; width: 100%; height: 60px; background-color: darkgreen;">
                <div class="container">
                    <p style="text-align: center; padding: 10px; color: white;"> &copy; Algonquin College 2010 – <?php
                        date_default_timezone_set("America/Toronto");
                        print Date("Y");
                        ?>.
                        All Rights Reserved</p></div>        
            </footer>
    </body>
</html>
