<?php
session_start();
$agreeToTerms = $_POST["agreeToTerms"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    
    if (isset($_POST['btnSubmit'])) 
        {
        if (!isset($_POST['agreeToTerms'])) 
        {
         $agreeErr = "<font color=red>YOU MUST AGREE THE TERMS AND CONDITIONS!</font>";
        } else 
        {
            $_SESSION["agree"] = "yes";
            header("Location:CustomerInfo.php");
        }
    }
}
?>





<html>
    <head>
        <style>
            p.solid {border-style: solid;}

            .button {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 15px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
            }

            .button2 {background-color: #008CBA;}




        </style>

        <meta charset="UTF-8">
        <title>Lab4</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="Site.css">
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>                        
                        </button>
                        <a class="navbar-brand" href="#">Algonquin College</a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="Index.php">Home</a></li>
                            <li><a href="Disclaimer.php">Terms and Conditions</a></li>
                            <li><a href="CustomerInfo.php">Customer Information</a></li>
                            <li><a href="DepositCalculator.php">Calculator</a></li>
                            <li><a href="Complete.php">Complete</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <h1 align="center">Terms and Conditions</h1>

            <p align="center" class="solid">I agree to abide by the Bank's Terms and Conditions and rules in force 
                and the changes thereto in Terms and<br> Conditions from time to time relating to my account as communicated
                and made available on the Bank's website <br> <br>

                I agree that the bank before opening any deposit account, will carry out due diligence as required
                under Know<br> Your Customer guidelines of the bank. I would be required to submit necessary documents or 
                proofs, such as<br> identity, address, photograph and any such information. I agree to submit the above documents
                again at periodic<br> intervals, as may be required by the bank. <br> <br>

                I agree that the Bank can at its sole discretion, amend any of the services/facilities given in my account
                either<br> wholly or partially at any time by giving me at least 30 days notice and/or provide an option to me to
                switch to<br> other services/facilities.

            </p>


            <br>

<?php echo $agreeErr; ?>
            <br>

            <input type="checkbox" name="agreeToTerms" value="agreeToTerms"/> I have read and agree with the terms and conditions
            <br>
            <input type = "submit" value = "Start" name="btnSubmit" class="button button2"/> 



            <footer style="position: absolute; bottom: 0; width: 100%; height: 60px; background-color: darkgreen;">
                <div class="container">
                    <p style="text-align: center; padding: 10px; color: white;"> &copy; Algonquin College 2010 – <?php
date_default_timezone_set("America/Toronto");
print Date("Y");
?>.
                        All Rights Reserved</p></div>        
            </footer>
    </body>
</html>
