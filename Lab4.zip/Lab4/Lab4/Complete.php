<?php
session_start();
session_destroy();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Lab4</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <style>
            .spanclass{
                color:blue;
            } 

        </style>

        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="#">Algonquin College</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="Index.php">Home</a></li>
                        <li><a href="Disclaimer.php">Terms and Conditions</a></li>
                        <li><a href="CustomerInfo.php">Customer Information</a></li>
                        <li><a href="DepositCalculator.php">Calculator</a></li>
                        <li><a href="Complete.php">Complete</a></li>
                    </ul>
                </div>
            </div>
        </nav>


        <?php
        if (isset($_SESSION['name'])) {
            echo "<h1 class='yourClass'>Thank you for using our deposit calculator tool <span class='spanclass'>" . $_SESSION['name'] . "</span></h1>";
            echo "<p>An email about the details of our GIC has been sent to " . $_SESSION['email'] . "</p>";
        }
        else
        {
            echo "<h1>Thank you for using our deposit calculator tool</h1>";
        }
        
        
        ?>







        <footer style="position: absolute; bottom: 0; width: 100%; height: 60px; background-color: darkgreen;">
            <div class="container">
                <p style="text-align: center; padding: 10px; color: white;"> &copy; Algonquin College 2010 – <?php
                    date_default_timezone_set("America/Toronto");
                    print Date("Y");
                    ?>.
                    All Rights Reserved</p></div>        
        </footer>

    </body>
</html>
