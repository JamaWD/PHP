<?php
session_start();
if(!isset($_SESSION['agree']))
{
      header("Location:Disclaimer.php");
}

$_SESSION['name'] = $_POST['name'];
$_SESSION['postalcode'] = $_POST['postalcode'];
$_SESSION['phonenumber'] = $_POST['phonenumber'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['preferredContact'] = $_POST['preferredContact'];
$_SESSION['contactTimes'] = $_POST['contactTimes'];




 
 $name = $_POST["name"];
 $postalcode = $_POST["postalcode"];
 $phonenumber = $_POST["phonenumber"];
 $email = $_POST["email"];
 $preferredContact = $_POST["preferredContact"];
 $contactTimes = $_POST["contactTimes"];
 
$nameErr = $postalcodeErr = $phonenumberErr = $emailErr = $preferredContactErr =
$contactTimesErr = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  

if (empty($_POST["name"])) 
 {
    $nameErr = "<p><font color=red>*Name is required*</font></p>";
 }
  
 if (!preg_match("/^[A-Z]\d[A-Z]\ ?\ \d[A-Z]\d$/", $postalcode))
 {
      $postalcodeErr = "<p><font color=red>*Incorrect postal code*</font></p>";
 }
 
 if (!preg_match("/^[2-9]\d\d-[2-9]\d\d\-\d{4}$/", $phonenumber))
 {
     $phonenumberErr = "<p><font color=red>*Incorrect phone number*</font></p>";
 }
 
  
 if (!preg_match("/^[A-Za-z\d.]+\@[A-Za-z\d]+\.[A-Za-z.]{2,4}$/" , $email))
 {
     $emailErr = "<p><font color=red>*Invalid email*</font></p>";
 }
 
 if ($preferredContact === "Phone" && !isset($contactTimes)) 
 {
     $contactTimesErr = "<p><font color=red>*When preferred contact is phone, you must select a contact time*</font></p>";
 }
 
  if (!$nameErr && !$postalcodeErr && !$phonenumberErr && !$emailErr && !$contactTimesErr)
  {
        header("Location:DepositCalculator.php");
  }
  
}
 
?>

<html>
    <head>


        <meta charset="UTF-8">
        <title>Lab4</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>                        
                        </button>
                        <a class="navbar-brand" href="#">Algonquin College</a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="Index.php">Home</a></li>
                            <li><a href="Disclaimer.php">Terms and Conditions</a></li>
                            <li><a href="CustomerInfo.php">Customer Information</a></li>
                            <li><a href="DepositCalculator.php">Calculator</a></li>
                            <li><a href="Complete.php">Complete</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <h1 align="center">Customer Information</h1>

            <table>

                <tr>
                    <td>Name:</td><td><input type = "text" placeholder="Name" name = "name" value="<?= isset($_POST['name']) ? $_POST['name'] : ''; ?>" /><?php echo $nameErr;?> </td>
                </tr>

                <tr>
                    <td>Postal Code:</td><td><input type = "text" placeholder="Postal Code" name = "postalcode" value="<?= isset($_POST['postalcode']) ? $_POST['postalcode'] : ''; ?>" /> <?php echo $postalcodeErr;?></td>
                </tr>

                <tr>
                    <td>Phone Number:</td><td><input type = "text" placeholder="Phone" name = "phonenumber" value="<?= isset($_POST['phonenumber']) ? $_POST['phonenumber'] : ''; ?>" /> <?php echo $phonenumberErr;?></td>

                </tr>

                <tr>
                    <td>Email Address:</td><td><input type = "text" placeholder="Email" name = "email" value="<?= isset($_POST['email']) ? $_POST['email'] : ''; ?>" /> <?php echo $emailErr;?></td>
                </tr>

            </table




            <div>    
                <br><br><h4>Preferred Contact Method:</h4>
            </div> 

            <input id="preferredContactPhone" name="preferredContact" type="radio" value="Phone"> Phone
            <input id="preferredContactEmail" name="preferredContact" type="radio" value="Email"> Email

            <h4>If phone is selected, when can we contact you? (check all applicable)</h4>

            <input type="checkbox" name="contactTimes[]" value="morning"/>Morning
        </tr>
        <tr>
        <input type="checkbox" name="contactTimes[]" value="afternoon"/>Afternoon
    </tr>
    <tr>
    <input type="checkbox" name="contactTimes[]" value="evening"/>Evening
    <?php echo $contactTimesErr;?>


    <input type = "submit" value = "Submit" style="position: absolute; top: 515px; left: 650px;" name="btnSubmit"/>
    <input type="reset" value="Clear" style="position: absolute; top: 515px; left: 750px;">




    <footer style="position: absolute; bottom: 0; width: 100%; height: 60px; background-color: darkgreen;">
        <div class="container">
            <p style="text-align: center; padding: 10px; color: white;"> &copy; Algonquin College 2010 – <?php
                date_default_timezone_set("America/Toronto");
                print Date("Y");
                ?>.
                All Rights Reserved</p></div>        
    </footer>
</body>
</html>
