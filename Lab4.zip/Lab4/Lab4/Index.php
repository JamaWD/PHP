<html>
    <head>
        <meta charset="UTF-8">
        <title>Lab4</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="#">Algonquin College</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="Index.php">Home</a></li>
                        <li><a href="Disclaimer.php">Terms and Conditions</a></li>
                        <li><a href="CustomerInfo.php">Customer Information</a></li>
                        <li><a href="DepositCalculator.php">Calculator</a></li>
                        <li><a href="Complete.php">Complete</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <h1>Welcome to Algonquin Bank</h1>

        <p>Algonquin Bank is Algonquin College student's most loved bank. We provide a set of tools<br>
            for Algonquin College students to manage their finance</p>

        <ul><li><a href="DepositCalculator.php">Deposit Calculator</a></li></ul>

        <footer style="position: absolute; bottom: 0; width: 100%; height: 60px; background-color: darkgreen;">
            <div class="container">
                <p style="text-align: center; padding: 10px; color: white;"> &copy; Algonquin College 2010 – <?php date_default_timezone_set("America/Toronto");
print Date("Y"); ?>.
                    All Rights Reserved</p></div>        
        </footer>

    </body>
</html>
