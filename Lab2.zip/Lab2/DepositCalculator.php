<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
 <?php
 $name = $_POST["name"];
 $principal = $_POST["principal"];
 $interest = $_POST["interest"];
 $years = $_POST["years"];
 $postalcode = $_POST["postalcode"];
 $phonenumber = $_POST["phonenumber"];
 $email = $_POST["email"];
 $preferredContact = $_POST["preferredContact"];
 $contactTimes = $_POST["contactTimes"];



 // Required field names
$required = array('name', 'principal', 'interest', 'years', 'postalcode', 'phonenumber' , 'email', 'preferredContact', 'contactTimes');     
 
// i am looping over the field names to make sure they exist and is not empty

$error = false;

foreach($required as $field) {
  if (empty($_POST[$field])) {
    $error = true;
  }
}

if ($error || !is_numeric($_POST['principal']) || $principal < 0 || !is_numeric($_POST['interest']) || $interest < 0) 
{
    error();
}

else 
{
    $error = false;
}

function error() {
    echo "<h1>Thank you {$_POST['name']}, for using our deposit Calculator!</h1>";
    echo "<p>However we can not process your request because of the following input errors:</p>";
    echo '<ul><li>The principal amount must be numeric and greater than 0</li>';
    echo '<li>The principal amount must be numberic and non-negative</li>';
    echo '<li>Postal code can not be blank</li>';
    echo '<li>Phone number can not be blank</li>';
    echo '<li>When preferred contact method is phone, you have to select one or more contact times</li>';
    echo '</ul>';
}


 ?>
  




<html>
    


    
    

    <head>
        <meta charset="UTF-8">
        <title></title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    </head>
    <body>
        
       
    <?php
    
   
    
      if (!$error)
      {
      
      echo "<h1>Thank you {$_POST['name']}, for using our deposit Calculator!</h1>";
     
      }
      
     if (!$error)
      {
      	$contactTimes = "";

        for ($i=0; $i < count($_POST['contactTimes']); $i++) { 
          $contactTimes .= $_POST['contactTimes'][$i] . ( ($i + 1) != count($_POST['contactTimes']) ? " or " : "");
        }

        if(strcasecmp($preferredContact, "Phone") == 0) {
        	echo "Our customer service department will call you tomorrow $contactTimes at $phonenumber";
        }       
        else {
        	echo "Our customer service department will email you tomorrow at " . $email;
        }
      }
      
      if (!$error)
      {
          echo "<p><br>The following is the result of the calculation</p>";
          echo "<table border='1'>
          <tr>
          <th>Year</th>
          <th>Principal at Year Start</th>
          <th>Interest for the Year</th>
          </tr>";
          
          $principleAtYearStart = $principal;
          for ($i = 1; $i<= $years; $i++)
          {
              
              $interestAmount =($principleAtYearStart * $interest) / 100.0;
              
              echo "<tr>";
              echo "<td>";
              echo $i;
              echo "</td>";              
              echo "<td>";
              echo printf("%.2f", $principleAtYearStart);
              echo "</td>"; 
              echo "<td>";
              echo printf("%.2f", $interestAmount);
              echo "</td>";  
              echo "</tr>";
         
              $principleAtYearStart += $interestAmount;
              
              
          }
          
          
          
          echo "</table>";
      }
       
     
 
  ?>
  
 
   
   
  





          
          
          
          
     
     
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>    
    </body>
</html>
